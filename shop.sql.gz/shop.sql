-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Янв 31 2019 г., 23:21
-- Версия сервера: 5.6.41
-- Версия PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `brand_info`
--

CREATE TABLE `brand_info` (
  `id_brand_info` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `short_info` varchar(30) NOT NULL,
  `info` varchar(450) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `brand_info`
--

INSERT INTO `brand_info` (`id_brand_info`, `name`, `short_info`, `info`) VALUES
(1, 'Mango People T-shirt     ', '', ''),
(2, 'blaze leggings ', '', ''),
(3, 'alexa sweater ', '', ''),
(4, 'agnes top', '', ''),
(5, 'sylva sweater  ', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id_cart` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_catalog` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `id_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog`
--

CREATE TABLE `catalog` (
  `id_catalog` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  `price` double NOT NULL,
  `id_gender` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `catalog`
--

INSERT INTO `catalog` (`id_catalog`, `id_product`, `price`, `id_gender`) VALUES
(1, 1, 52, 1),
(2, 2, 52, 2),
(3, 3, 52, 1),
(4, 4, 52, 2),
(5, 5, 52, 2),
(6, 6, 52, 1),
(7, 7, 52, 1),
(8, 8, 52, 1),
(9, 9, 52, 1),
(10, 10, 52, 1),
(11, 11, 52, 1),
(12, 12, 52, 1),
(13, 13, 52, 1),
(14, 14, 52, 1),
(15, 15, 52, 1),
(16, 16, 52, 1),
(17, 17, 52, 1),
(18, 18, 52, 2),
(19, 19, 52, 2),
(20, 20, 52, 2),
(21, 21, 52, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `gender`
--

CREATE TABLE `gender` (
  `id_gender` int(11) NOT NULL,
  `genders` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `gender`
--

INSERT INTO `gender` (`id_gender`, `genders`) VALUES
(1, 'Men'),
(2, 'Woman');

-- --------------------------------------------------------

--
-- Структура таблицы `image`
--

CREATE TABLE `image` (
  `id_img` int(11) NOT NULL,
  `src` varchar(100) NOT NULL,
  `src_mini` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `image`
--

INSERT INTO `image` (`id_img`, `src`, `src_mini`) VALUES
(1, 'img\\items-img1.png', 'img\\img_mini\\items-img1.png'),
(2, 'img\\items-img2.png', 'img\\img_mini\\items-img2.png'),
(3, 'img\\items-img3.png', 'img\\img_mini\\items-img3.png'),
(4, 'img\\items-img4.png ', 'img\\img_mini\\items-img4.png'),
(5, 'img\\items-img5.png ', 'img\\img_mini\\items-img5.png'),
(6, 'img\\items-img6.png', 'img\\img_mini\\items-img6.png'),
(7, 'img\\items-img7.png', 'img\\img_mini\\items-img7.png'),
(8, 'img\\items-img8.png', 'img\\img_mini\\items-img8.png'),
(9, 'img\\product-1.jpg ', 'img\\img_mini\\product-1.jpg'),
(10, 'img\\product-2.jpg', 'img\\img_mini\\product-2.jpg'),
(11, 'img\\product-3.jpg', 'img\\img_mini\\product-3.jpg'),
(12, 'img\\product-4.jpg', 'img\\img_mini\\product-4.jpg'),
(13, 'img\\product-5.jpg', 'img\\img_mini\\product-5.jpg'),
(14, 'img\\product-6.jpg', 'img\\img_mini\\product-6.jpg'),
(15, 'img\\product-7.jpg', 'img\\img_mini\\product-7.jpg'),
(16, 'img\\product-8.jpg', 'img\\img_mini\\product-8.jpg'),
(17, 'img\\product-9.jpg', 'img\\img_mini\\product-9.jpg'),
(18, 'img/other-product-1.jpg', 'img\\img_mini\\other-product-1.jpg'),
(19, 'img/other-product-2.jpg', 'img\\img_mini\\other-product-2.jpg'),
(20, 'img/other-product-3.jpg', 'img\\img_mini\\other-product-3.jpg'),
(21, 'img/other-product-4.jpg', 'img\\img_mini\\other-product-4.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `product`
--

CREATE TABLE `product` (
  `id_product` int(11) NOT NULL,
  `id_brand_info` int(11) NOT NULL,
  `id_img` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `product`
--

INSERT INTO `product` (`id_product`, `id_brand_info`, `id_img`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10),
(11, 1, 11),
(12, 1, 12),
(13, 1, 13),
(14, 1, 14),
(15, 1, 15),
(16, 1, 16),
(17, 1, 17),
(18, 2, 18),
(19, 3, 19),
(20, 4, 20),
(21, 5, 21);

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `id_review` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `review` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `status`
--

CREATE TABLE `status` (
  `id_status` int(11) NOT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `status`
--

INSERT INTO `status` (`id_status`, `status`) VALUES
(1, 'В корзине'),
(2, 'В обработке'),
(3, 'Выполняется'),
(4, 'Выполнен'),
(5, 'Отклонен');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `credit_card` varchar(30) NOT NULL,
  `id_gender` int(11) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_user`, `username`, `email`, `password`, `credit_card`, `id_gender`, `role`) VALUES
(1, 'Kirill', 'mymail@list.ru', '25d55ad283aa400af464c76d713c07ad', '3333-3333-3333-3333', 1, 0),
(2, 'Marya', 'mail@list.ru', '25d55ad283aa400af464c76d713c07ad', '3333-3333-3333-3333', 2, 0),
(3, 'Petya', 'lobanovk@list.ru', '25d55ad283aa400af464c76d713c07ad', '3333-3333-3333-3333', 1, 0),
(4, 'Sasha', 'lobanov@list.ru', '25d55ad283aa400af464c76d713c07ad', '3333-3333-3333-3333', 1, 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `brand_info`
--
ALTER TABLE `brand_info`
  ADD PRIMARY KEY (`id_brand_info`);

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id_cart`);

--
-- Индексы таблицы `catalog`
--
ALTER TABLE `catalog`
  ADD PRIMARY KEY (`id_catalog`);

--
-- Индексы таблицы `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`id_gender`);

--
-- Индексы таблицы `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id_img`);

--
-- Индексы таблицы `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id_product`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id_review`);

--
-- Индексы таблицы `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id_status`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `brand_info`
--
ALTER TABLE `brand_info`
  MODIFY `id_brand_info` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id_cart` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `catalog`
--
ALTER TABLE `catalog`
  MODIFY `id_catalog` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `gender`
--
ALTER TABLE `gender`
  MODIFY `id_gender` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `image`
--
ALTER TABLE `image`
  MODIFY `id_img` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `product`
--
ALTER TABLE `product`
  MODIFY `id_product` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id_review` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `status`
--
ALTER TABLE `status`
  MODIFY `id_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
